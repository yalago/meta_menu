
<?php $__env->startSection('background'); ?>
style="background-image: url(<?php echo e(url($vendor_info['vendor_cover_img'])); ?>)"
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div id="home-container">
    <div id="home-products-list" class="">
        <div class="home-carousel-container position-fixed  w-100 p-2 bg-black">
            <div id="products-categories-slider" class="owl-carousel owl-theme ">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item center-content-vertically border border-1 p-3 custom-rounded-border text-light active-cat-pill"
                    data-target="cat-<?php echo e($item['category_id']); ?>">
                    <img src="<?php echo e(asset('assets/images/meal-slice.png')); ?>" class="me-2" alt="">
                    <?php echo e($item['category_name']); ?>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="categories-container">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="cat-<?php echo e($item['category_id']); ?>" class="product-list-category active-cat">
                <?php $__currentLoopData = $products['data']['products_menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex py-2 product-in-list">
                    <div class="w-25 center-content-vertically image-video-wrap">
                        <a
                            href="<?php echo e(route('showproductBranch', ['vendor_uuid' => $vendor_uuid, $product['product_id'], 'table_id' => $table_id])); ?>">
                            <img src="<?php echo e($product['image']); ?>" alt="" class="rounded-circle"> </a>
                        <?php if($product['video'] != null): ?>
                        <video playsinline controls="false" muted="muted" class="display-none meal-video">
                            <source src="<?php echo e($product['video']); ?>" />
                        </video>
                        <?php endif; ?>
                    </div>
                    <div class="text-light px-3 center-content-vertically">
                        <a href="<?php echo e(route('showproductBranch', ['vendor_uuid' => $vendor_uuid, $product['product_id'], 'table_id' => $table_id])); ?>"
                            class="text-light">
                            <?php echo e($product['product_name']); ?>

                        </a>
                    </div>
                    <div class=" center-content-vertically actions ms-auto">
                        <a href="<?php echo e(route('showproductBranch', ['vendor_uuid' => $vendor_uuid, $product['product_id'], 'table_id' => $table_id])); ?>"
                            class="rounded-circle bg-teritary mx-1 center-content add-to-cart-in-list">
                            <img src="<?php echo e(asset('assets/images/plus-rounded.png')); ?>" alt="">
                        </a>
                        <?php if($product['video'] != null): ?>
                        <a class=" rounded-circle bg-gray mx-1 center-content" onclick="togglePlayVideo(this)">
                            <img src="<?php echo e(asset('assets/images/rictangle.png')); ?>" alt="">
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>


</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('assets/lib/OwlCarousel2/dist/owl.carousel.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('assets/lib/OwlCarousel2/dist/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/lib/OwlCarousel2/dist/assets/owl.theme.default.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('csutom_scripts'); ?>
<script>
    $(document).ready(function () {
    $('#products-categories-slider').owlCarousel({
    // loop: true,
    margin: 10,
    responsiveClass: true,
    navigation: false,
    rtl: true,
    responsive: {
    0: {
    items: 3,
    nav: true
    },
    600: {
    items: 3,
    nav: false
    },
    1000: {
    items: 5,
    nav: true,
    loop: false
    }
    },
    })})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\meta_menu\resources\views/frontend/pages/home.blade.php ENDPATH**/ ?>