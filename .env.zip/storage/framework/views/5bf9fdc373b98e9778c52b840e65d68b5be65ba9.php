<div id="header" class="px-2">
    <div class="w-25 text-primary center-content-vertically">
        <div class="me-2 ">
            <div class="position-relative">
                <a id="menu-trigger"
                    href="<?php echo e(route('branch', ['vendor_uuid' => $vendor_uuid, 'table_id' => request()->table_id])); ?>"
                    click="redirectBack()">
                    <img src="<?php echo e(asset('assets/images/right-arrow.png')); ?>" alt="">
                </a>
            </div>
        </div>

    </div>
    <div class="w-50 text-primary center-content-vertically justify-content-center">
        <h3 class="mb-3 text-center">
            <?php echo $__env->yieldContent('page-title'); ?>
        </h3>
    </div>
    
</div>
<script>
    window.window.homeURL = '/gerizapaints/menu/556/1'
</script>
<?php /**PATH C:\wamp64\www\meta_menu\resources\views/frontend/layouts/sections/header.blade.php ENDPATH**/ ?>