<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
    <link href="<?php echo e(asset('assets/lib/bootstrap/css/bootstrap.rtl.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/styles.rtl.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('styles'); ?>


</head>

<body>
    <div id="main-wrap" <?php echo $__env->yieldContent('background'); ?>>
        <?php echo $__env->make('frontend.layouts.sections.header_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="content-wrap" class="position-absolute mh-50 w-100 text-light p-3 pt-0">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php echo $__env->yieldContent('footer'); ?>
    </div>
</body>
<script src="<?php echo e(asset('assets/lib/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/lib/jquery/jquery-3.6.0.min.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
<script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
<?php echo $__env->yieldContent('csutom_scripts'); ?>
</html>
<?php /**PATH C:\wamp64\www\meta_menu\resources\views/frontend/layouts/home.blade.php ENDPATH**/ ?>