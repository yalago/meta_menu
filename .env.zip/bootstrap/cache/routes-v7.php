<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/pressOnCart' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pressOnCart',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/product_details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'product_details',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AvPthJtu7bRS84FX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/([^/]++)/(?|branch/([^/]++)(*:35)|([^/]++)/menu/([^/]++)/([^/]++)(*:73)|s(?|how(?|product/([^/]++)/([^/]++)(*:115)|ProductFullInfo(*:138))|ubmitOrder(*:157))|c(?|h(?|angeQuantity(*:186)|eckout(*:200))|o(?|upon\\-check(*:224)|ngratulations(*:245)))|add\\-to\\-basket/([^/]++)(*:279)|pay(?|\\-visa(*:299)|ment/status(*:318))|remove\\-from\\-basket(*:347)|track_order(*:366)))/?$}sDu',
    ),
    3 => 
    array (
      35 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'branch',
          ),
          1 => 
          array (
            0 => 'vendor_uuid',
            1 => 'table_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      73 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'productCategoryBranch',
          ),
          1 => 
          array (
            0 => 'vendor_uuid',
            1 => 'language',
            2 => 'category_id',
            3 => 'table_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      115 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'showproductBranch',
          ),
          1 => 
          array (
            0 => 'vendor_uuid',
            1 => 'product_id',
            2 => 'table_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      138 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'showProductFullInfo',
          ),
          1 => 
          array (
            0 => 'vendor_uuid',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      157 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'submitOrder',
          ),
          1 => 
          array (
            0 => 'vendor_uuid',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      186 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'changeQuantity',
          ),
          1 => 
          array (
            0 => 'vendor_uuid',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      200 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'checkout',
          ),
          1 => 
          array (
            0 => 'vendor_uuid',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      224 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'coupon.check',
          ),
          1 => 
          array (
            0 => 'vendor_uuid',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      245 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'congratulations',
          ),
          1 => 
          array (
            0 => 'vendor_uuid',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      279 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'addToBasket',
          ),
          1 => 
          array (
            0 => 'vendor_uuid',
            1 => 'product_id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      299 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pay.visa',
          ),
          1 => 
          array (
            0 => 'vendor_uuid',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      318 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'showProductFullInfoMenu',
          ),
          1 => 
          array (
            0 => 'vendor_uuid',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      347 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'removeFromBasket',
          ),
          1 => 
          array (
            0 => 'vendor_uuid',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      366 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'track_order',
          ),
          1 => 
          array (
            0 => 'vendor_uuid',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'pressOnCart' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pressOnCart',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@pressOnCart',
        'controller' => 'App\\Http\\Controllers\\HomeController@pressOnCart',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'pressOnCart',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'product_details' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'product_details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@product_details',
        'controller' => 'App\\Http\\Controllers\\HomeController@product_details',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'product_details',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'branch' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{vendor_uuid}/branch/{table_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'apiCheckVendor',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuBranchController@branch',
        'controller' => 'App\\Http\\Controllers\\MenuBranchController@branch',
        'namespace' => NULL,
        'prefix' => '/{vendor_uuid}',
        'where' => 
        array (
        ),
        'as' => 'branch',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'productCategoryBranch' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{vendor_uuid}/{language}/menu/{category_id}/{table_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'apiCheckVendor',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuBranchController@productCategoryBranch',
        'controller' => 'App\\Http\\Controllers\\MenuBranchController@productCategoryBranch',
        'namespace' => NULL,
        'prefix' => '/{vendor_uuid}',
        'where' => 
        array (
        ),
        'as' => 'productCategoryBranch',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'showproductBranch' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{vendor_uuid}/showproduct/{product_id}/{table_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'apiCheckVendor',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuBranchController@product',
        'controller' => 'App\\Http\\Controllers\\MenuBranchController@product',
        'namespace' => NULL,
        'prefix' => '/{vendor_uuid}',
        'where' => 
        array (
        ),
        'as' => 'showproductBranch',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'changeQuantity' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{vendor_uuid}/changeQuantity',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'apiCheckVendor',
        ),
        'uses' => 'OrderBasketController@changeQuantity',
        'controller' => 'OrderBasketController@changeQuantity',
        'namespace' => NULL,
        'prefix' => '/{vendor_uuid}',
        'where' => 
        array (
        ),
        'as' => 'changeQuantity',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'addToBasket' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{vendor_uuid}/add-to-basket/{product_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'apiCheckVendor',
        ),
        'uses' => 'App\\Http\\Controllers\\OrderBasketController@addToBasket',
        'controller' => 'App\\Http\\Controllers\\OrderBasketController@addToBasket',
        'namespace' => NULL,
        'prefix' => '/{vendor_uuid}',
        'where' => 
        array (
        ),
        'as' => 'addToBasket',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'submitOrder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{vendor_uuid}/submitOrder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'apiCheckVendor',
        ),
        'uses' => 'OrderBasketController@submitOrder',
        'controller' => 'OrderBasketController@submitOrder',
        'namespace' => NULL,
        'prefix' => '/{vendor_uuid}',
        'where' => 
        array (
        ),
        'as' => 'submitOrder',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pay.visa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{vendor_uuid}/pay-visa',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'apiCheckVendor',
        ),
        'uses' => 'OrderBasketController@submitOrderOnline',
        'controller' => 'OrderBasketController@submitOrderOnline',
        'namespace' => NULL,
        'prefix' => '/{vendor_uuid}',
        'where' => 
        array (
        ),
        'as' => 'pay.visa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'showProductFullInfoMenu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{vendor_uuid}/payment/status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'apiCheckVendor',
        ),
        'uses' => 'OrderBasketController@paymentStatus',
        'controller' => 'OrderBasketController@paymentStatus',
        'namespace' => NULL,
        'prefix' => '/{vendor_uuid}',
        'where' => 
        array (
        ),
        'as' => 'showProductFullInfoMenu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'removeFromBasket' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{vendor_uuid}/remove-from-basket',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'apiCheckVendor',
        ),
        'uses' => 'OrderBasketController@removeFromBasket',
        'controller' => 'OrderBasketController@removeFromBasket',
        'namespace' => NULL,
        'prefix' => '/{vendor_uuid}',
        'where' => 
        array (
        ),
        'as' => 'removeFromBasket',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'showProductFullInfo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{vendor_uuid}/showProductFullInfo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'apiCheckVendor',
        ),
        'uses' => 'OrderBasketController@showProductFullInfo',
        'controller' => 'OrderBasketController@showProductFullInfo',
        'namespace' => NULL,
        'prefix' => '/{vendor_uuid}',
        'where' => 
        array (
        ),
        'as' => 'showProductFullInfo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'coupon.check' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{vendor_uuid}/coupon-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'apiCheckVendor',
        ),
        'uses' => 'OrderBasketController@checkCoupon',
        'controller' => 'OrderBasketController@checkCoupon',
        'namespace' => NULL,
        'prefix' => '/{vendor_uuid}',
        'where' => 
        array (
        ),
        'as' => 'coupon.check',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{vendor_uuid}/checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'apiCheckVendor',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuBranchController@checkout',
        'controller' => 'App\\Http\\Controllers\\MenuBranchController@checkout',
        'namespace' => NULL,
        'prefix' => '/{vendor_uuid}',
        'where' => 
        array (
        ),
        'as' => 'checkout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'track_order' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{vendor_uuid}/track_order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'apiCheckVendor',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuBranchController@track_order',
        'controller' => 'App\\Http\\Controllers\\MenuBranchController@track_order',
        'namespace' => NULL,
        'prefix' => '/{vendor_uuid}',
        'where' => 
        array (
        ),
        'as' => 'track_order',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'congratulations' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{vendor_uuid}/congratulations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'apiCheckVendor',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuBranchController@congratulations',
        'controller' => 'App\\Http\\Controllers\\MenuBranchController@congratulations',
        'namespace' => NULL,
        'prefix' => '/{vendor_uuid}',
        'where' => 
        array (
        ),
        'as' => 'congratulations',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AvPthJtu7bRS84FX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:295:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000032f469ea000000003020c8cd";}";s:4:"hash";s:44:"vJd4iTFfq7DrLl2UNGMRQM/SsZasfdEJmta28td1kgM=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::AvPthJtu7bRS84FX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
